# WhatsApp Tag-All Bot

A WhatsApp group bot built with `whatsapp-web.js` that mentions all participants in a group using the `!tagall` command.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the bot:
   ```bash
   node index.js
   ```

3. Scan the QR code using WhatsApp mobile app.

In a group (where the account is admin), send:
```
!tagall
```

## PM2 Process Manager

```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## GitHub Actions Deployment

Set these secrets in your GitHub repository:

- `SSH_KEY`
- `SERVER_HOST`
- `SERVER_USER`
- `DEPLOY_PATH`

Push to `master` and GitHub will auto-deploy your code to your server.

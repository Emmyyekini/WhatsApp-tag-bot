const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client({
  authStrategy: new LocalAuth(),
  puppeteer: { headless: true }
});

client.on('qr', qr => qrcode.generate(qr, { small: true }));
client.on('ready', () => console.log('✅ Bot is ready'));

client.on('message', async msg => {
  if (msg.body.trim() === '!tagall') {
    const chat = await msg.getChat();
    if (!chat.isGroup) return msg.reply('❗ Use this in a group');

    const mentions = [];
    let text = '👥 ';

    for (const participant of chat.participants) {
      const contact = await client.getContactById(participant.id._serialized);
      mentions.push(contact);
      text += `@${contact.number} `;
    }

    await chat.sendMessage(text.trim(), { mentions });
  }
});

client.initialize();
